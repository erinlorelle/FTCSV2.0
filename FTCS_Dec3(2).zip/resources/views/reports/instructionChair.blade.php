@extends('layouts.master')

@section('content')

    <!-- Page Content -->
    <div class="container">
        <br><br>
        <section id="contact">

            <h1>Welcome to Instructions for Chairs (pdf)!</h1>
            <br><br>
    </div>

@endsection