<?php $__env->startSection('content'); ?>

    <!-- Page Content -->
    <div class="container">
        <br><br>
        <section id="contact">

            <h1>Welcome to Faculty!</h1>
            <br><br>
    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>