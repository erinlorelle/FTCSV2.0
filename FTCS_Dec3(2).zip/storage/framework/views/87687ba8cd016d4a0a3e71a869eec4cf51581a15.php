<?php $__env->startSection('content'); ?>

    <!-- Page Content -->
    <div class="container">
        <br><br>
        <section id="contact">
            <div class="container">
                <div class="row">
                    <div class="col-lg-8 mx-auto">
                        <br><br>
                        <h2>FTCS Login</h2>
                        <div class="col-sm-4">
                            <h2 class="mt-4"></h2>
                                <form name="login">
                                    <?php echo e(csrf_field()); ?>


                                    <?php echo $__env->make('layouts.flash', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

                                    <br>
                                    <div class="form-group" style="width: 250px;" style="text-align: center">
                                        Username: <input type="text" class="form-control" id="username" name="username">
                                    </div>

                                    <div class="form-group" style="width: 250px;" style="text-align: center">
                                        Password: <input type="password" class="form-control" id="password" name="password">
                                    </div>

                                    <div class="form-group">
                                    <button type="submit" class="btn btn-primary" onclick="check(this.form)" value="Login"> Submit </button>
                                    </div>
                                    <br><br><br><br>
                                    <?php echo $__env->make('layouts.errors', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

                                </form>
                                    
									
									

									
                                   
                            <br><br>
                        </div>
                    </div>
                </div>
            </div>
        </section>
    </div>

	<script language="javascript">
function check(form)/*function to check userid & password*/
{
 /* Admin check */
 if(form.username.value == "admin" && form.password.value == "password")
  {
    window.open("/facLogin") /*opens the target page while Id & password matches*/
      /*window.location.href = "/facLogin";*/
  }
  /* Dean check */
  else if(form.username.value == "dean" && form.password.value == "password")
  {
	window.open("/deanIn")/*opens the target page while Id & password matches*/  
  }
  /* CO check */
  else if(form.username.value == "credoff" && form.password.value == "password")
  {
	window.open("/coIn")/*opens the target page while Id & password matches*/  
  }
  /*the following code checkes whether the entered userid and password are matching*/
 else
 {
   alert("Incorrect Username or Password")/*displays error message*/
  }
}
</script>

<?php $__env->stopSection(); ?>






<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>