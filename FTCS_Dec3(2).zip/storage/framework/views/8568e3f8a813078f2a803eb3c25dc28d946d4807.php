<?php $__env->startSection('content'); ?>

    <!-- Page Content -->
    <div class="container">
        <br><br>
        <div>
            <h2 style="position: center">ETSU Course Section Qualifications Percentage Report</h2>
        </div>

        <div class="form-group">
            <form target= "_blank" style="float: right">
                <input type="button" class="btn btn-primary" value="Save as PDF" onclick="window.print()"/>
            </form>
            <br>
        </div>
        <br><br>
        <section id="contact">

            

            <select id="myInput" onclick="myFunction()">
                <option >All</option>
                <option >2018</option>
                <option >2017</option>
                <option >2016</option>
                <option >2015</option>
            </select>

            <script>
                function myFunction() {
                    // Declare variables
                    var input, filter, table, tr, td, i;
                    input = document.getElementById("myInput");
                    filter = input.value.toUpperCase();
                    table = document.getElementById("myTable");
                    tr = table.getElementsByTagName("tr");

                    // Loop through all table rows, and hide those who don't match the search query
                    for (i = 0; i < tr.length; i++) {
                        td = tr[i].getElementsByTagName("td")[3];
                        if (td) {
                            if (td.innerHTML.toUpperCase().indexOf(filter) > -1) {
                                tr[i].style.display = "";
                            } else {
                                tr[i].style.display = "none";
                            }
                        }
                    }
                }
            </script>
            <style>

                #myInput {
                    background-image: url('/css/searchicon.png'); /* Add a search icon to input */
                    background-position: 10px 12px; /* Position the search icon */
                    background-repeat: no-repeat; /* Do not repeat the icon image */
                    width: 100%; /* Full-width */
                    font-size: 16px; /* Increase font-size */
                    padding: 12px 20px 12px 40px; /* Add some padding */
                    border: 1px solid #ddd; /* Add a grey border */
                    margin-bottom: 12px; /* Add some space below the input */
                }

                #myTable {
                    border-collapse: collapse; /* Collapse borders */
                    width: 100%; /* Full-width */
                    border: 1px solid #ddd; /* Add a grey border */
                    font-size: 18px; /* Increase font-size */
                }

                #myTable th, #myTable td {
                    text-align: left; /* Left-align text */
                    padding: 12px; /* Add padding */
                }

                #myTable tr {
                    /* Add a bottom border to all table rows */
                    border-bottom: 1px solid #ddd;
                }

                #myTable tr.header, #myTable tr:hover {
                    /* Add a grey background color to the table header and on hover */
                    background-color: #f1f1f1;
                }

            </style>
            <table id="myTable">
                <tr class="header">
                    <th style="width:60%;">Department</th>
                    <th style="width:40%;">Total Course Sections</th>
                    <th style="width:40%;">%</th>
                    <th style="width:40%;">Number Academically Qualified</th>
                    <th style="width:40%;">%</th>
                    <th style="width:40%;">Number Professionally Qualified</th>
                    <th style="width:40%;">%</th>
                    <th style="width:40%;">Number Graduate Assistants</th>
                    <th style="width:40%;">%</th>
                    <th style="width:40%;">Missing Transcripts</th>
                </tr>
                <?php $users = App\User::all(); ?>
                <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($user->department); ?>)</td>
                        <td>23</td>
                        <td>100%</td>
                        <td>91% <font hidden><?php echo e($user->start_year); ?></font></td>
                        <td>2</td>
                        <td>9</td>
                        <td>0</td>
                        <td>0%</td>
                        <td>2</td>

                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            </table>
            <br><br>
    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>