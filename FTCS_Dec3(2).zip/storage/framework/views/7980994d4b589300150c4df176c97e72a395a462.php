<?php $__env->startSection('content'); ?>

        <html>
    <div class="container">

        <?php echo $__env->make('layouts.flash', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

        <body>
        <h2 style="margin: 20px">List of Roles</h2>
        <table class="table" style="margin: 20px">
            <thead>
            <tr>
                <th>Id</th>
                <th>Title</th>
                <th>Description</th>
                <th>Update</th>
                <th>Delete</th>
            </tr>
            </thead>

            <?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                <tr>
                    <td><?php echo e($role->id); ?></td>
                    <td><?php echo e($role->title); ?></td>
                    <td><?php echo e($role->description); ?></td>
                    <td><a href="roles/edit/<?php echo e($role->id); ?>"><i class="fas fa-pencil-alt"></i></a></td>
                    <td><a href="roles/delete/<?php echo e($role->id); ?>"><i class="far fa-trash-alt"></i></a></td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        </table>


        </body>

        <div class="col-sm-8 blog-main">
            <br>
            <h4>Add a Role</h4>

            <form method="POST" action="/roles">
                <?php echo e(csrf_field()); ?>


                <div class="form-group">
                    <input type="text" class="form-control" id="title" name="title" placeholder="Role Title">
                </div>

                <div class="form-group">
                    <input type="text" class="form-control" id="description" name="description" placeholder="Role Description">
                </div>

                <div class="form-group">
                    <button type="submit" class="btn btn-primary">Submit</button>
                </div>

                <?php echo $__env->make('layouts.errors', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            <br>
            </form>

        </div>

    </div>
    </html>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>