<?php $__env->startSection('content'); ?>

    <!-- Header with Background Image -->
    <header class="business-header" >
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <!-- <h1 class="display-3 text-center text-white mt-4">Faculty Teaching Credentials System</h1> -->

                </div>
            </div>
        </div>
    </header>



    <div class="container">

        <div class="row">
            <div class="col-sm-8">
                <br>
                <h2 style="color: midnightblue">Credentials Successfully Updated</h2>

                <!-------------- DEAN SETS CREDENTIALS OF INSTRUCTORS IN THE COLLEGE ------------------>

                <br><br><br><br><br><br>

                <div class="form-group">
                    <form action="deanIn">
                        <input type="submit" class="btn btn-primary" value="Dean Homepage" />
                    </form>
                    <br>
                </div>


                <br>
            </div>
            <div class="col-sm-4">
                <h2 class="mt-4">Contact Us</h2>
                <address>
                    <strong>Marsh Grube (SACS Director)</strong>
                    <br>1276 Gilbreath Dr
                    <br>Johnson City, TN 37614
                    <br>
                </address>
                <address>
                    <abbr title="Phone">P:</abbr>
                    (423) 439-4150
                    <br>
                    <abbr title="Email">E:</abbr>
                    <a href="mailto:#">grube@etsu.edu</a>
                </address>
                <a href="https://www.etsu.edu/academicaffairs/" target="_blank">Office of the Provost and Vice President</a>
            </div>
        </div>
    </div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.masterOut', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>