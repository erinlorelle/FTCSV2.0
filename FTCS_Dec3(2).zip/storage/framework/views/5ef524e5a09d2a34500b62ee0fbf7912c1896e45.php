<?php $__env->startSection('content'); ?>

    <!-- Header with Background Image -->
    <header class="business-header" >
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <!-- <h1 class="display-3 text-center text-white mt-4">Faculty Teaching Credentials System</h1> -->

                </div>
            </div>
        </div>
    </header>

										

<div class="container">

        <div class="row">
            <div class="col-sm-8">
                <br>
                <h2 style="color: midnightblue">Department Instructor Credential Page</h2>
                
				    				    <!-------------- CO SETS CREDENTIALS OF INSTRUCTORS TEACHING IN THEIR DEPARTMENT ------------------>
				
<br>				
<center>				
<form>
Dr. Awesome Prof
  <select name="colleges">
    <option value="Academic">Academic</option>
	<option value="Professional">Professional</option>
	<option value="G/A">G/A</option>
  </select>
   
</form>
<br>

<form>
Dr. Crazy Dude
  <select name="departments">
    <option value="Academic">Academic</option>
	<option value="Professional">Professional</option>
	<option value="G/A">G/A</option>
  </select>
  
</form>
<br>

<form>
Dr. Buttholewho Giveshomework
  <select name="departments">
    <option value="Academic">Academic</option>
	<option value="Professional">Professional</option>
	<option value="G/A">G/A</option>
  </select>
  
</form>
<br>

<form>
Dr. Douchewith Noofficehours
  <select name="departments">
    <option value="Academic">Academic</option>
	<option value="Professional">Professional</option>
	<option value="G/A">G/A</option>
  </select>
  
</form>


<br><br><br><br><br><br><br><br>

<form action="/coIn">
<input type="submit" value="Return">
</form>              
</center>                
<br>
            </div>
            <div class="col-sm-4">
                <h2 class="mt-4">Contact Us</h2>
                <address>
                    <strong>Marsh Grube (SACS Director)</strong>
                    <br>1276 Gilbreath Dr
                    <br>Johnson City, TN 37614
                    <br>
                </address>
                <address>
                    <abbr title="Phone">P:</abbr>
                    (423) 439-4150
                    <br>
                    <abbr title="Email">E:</abbr>
                    <a href="mailto:#">grube@etsu.edu</a>
                </address>
                <a href="https://www.etsu.edu/academicaffairs/" target="_blank">Office of the Provost and Vice President</a>
            </div>
        </div>
    </div>


  <?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.masterOut', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>