

<html>
<head>

    <!-- Bootstrap core CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.0/css/bootstrap.min.css" integrity="sha384-9gVQ4dYFwwWSjIDZnLEWnxCjeSWFphJiwGPXr1jddIhOegiu1FwO5qRGvFXOdJZ4" crossorigin="anonymous">

    <!-- Custom styles for this template -->
    <link href="css/album.css" rel="stylesheet">

    <div class="container">
<body>
<h2 style="margin: 20px"><?php echo e($assignTeach->course_number); ?> <?php echo e($assignTeach->course_name); ?></h2>


<div class="col-sm-8 blog-main" style="margin: 20px">
    <hr>
    <br>

    <form method="POST" action="/courses/assignTeacher<?php echo e($assignTeach->id); ?>">
        <?php echo e(csrf_field()); ?>

        <?php echo e(method_field('PATCH')); ?>


        <h4>Assign a teacher to this course</h4>

        <select name="teacher">
            <?=$users = App\User::whereHas('roles', function ($query){$query->where('title', 'Professor');})->get();?>
            <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($user->first_name); ?>"><?php echo e($user->first_name); ?> <?php echo e($user->last_name); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>

        <br><br>

        <div class="form-group">
            <button type="submit" class="btn btn-primary">Submit</button>
        </div>



        <?php echo $__env->make('layouts.errors', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        <br>
    </form>

</div>

</div>
</html>