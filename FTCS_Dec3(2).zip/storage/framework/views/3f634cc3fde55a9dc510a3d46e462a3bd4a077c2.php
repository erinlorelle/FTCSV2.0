<?php $__env->startSection('content'); ?>

    <!-- Header with Background Image -->
    <header class="business-header" >
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <!-- <h1 class="display-3 text-center text-white mt-4">Faculty Teaching Credentials System</h1> -->

                </div>
            </div>
        </div>
    </header>

    <!-- Page Content -->
    <div class="container">

        <div class="row">
            <div class="col-sm-8">
                <br>
                <h2 style="color: midnightblue">Dr. Jeff Roach</h2>
                <h2 class="mt-4">Welcome to the Admin homepage for the ETSU Faculty Teaching Credentials System (FTCS)</h2>
				
                
				
				
College:				
<form action="/deanIn">
  <select name="colleges">
    <option value="Academic Affairs">Academic Affairs</option>
	<option value="Business and Technology">Business and Technology</option>
	<option value="Arts and Sciences">Arts and Sciences</option>
  </select>
  
  <input type="submit" value="Enter as Dean">
</form>
<br>
Department:
<form action="/coIn">
  <select name="departments">
    <option value="Academic Affairs">Academic Affairs</option>
	<option value="Accounting">Accounting</option>
	<option value="Arts and Sciences">Arts and Sciences</option>
	<option value="Biological Sciences">Biological Sciences</option>
	<option value="Chemistry">Chemistry</option>
	<option value="Communication">Communication</option>
  </select>
  
  <input type="submit" value="Enter as CO">
</form>
<br>

                <div class="form-group">
                    <form action="credPage">
                        <input type="submit" class="btn btn-primary" value="Credential Officer Management" />
                    </form>
                    <br>
                </div>
				



                <br><br>
            </div>
            <div class="col-sm-4">
                <h2 class="mt-4">Contact Us</h2>
                <address>
                    <strong>Marsh Grube (SACS Director)</strong>
                    <br>1276 Gilbreath Dr
                    <br>Johnson City, TN 37614
                    <br>
                </address>
                <address>
                    <abbr title="Phone">P:</abbr>
                    (423) 439-4150
                    <br>
                    <abbr title="Email">E:</abbr>
                    <a href="mailto:#">grube@etsu.edu</a>
                </address>
                <a href="https://www.etsu.edu/academicaffairs/" target="_blank">Office of the Provost and Vice President</a>
            </div>
        </div>
    </div>


   <?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.masterBOut', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>